// const express = require('express');
// const corsMiddleware = require('./middleware/corsMiddleware');
// const trackRoutes = require('./routes/track');
// const trackDataRoutes = require('./routes/trackdata');
// const authRoutes = require('./routes/auth');
// const app = express();
// const path = require('path');
// const bodyParser = require('body-parser');

// // Middleware
// app.use(bodyParser.urlencoded({ extended: true }));
// app.use(bodyParser.json());
// app.use(corsMiddleware);

// app.use(express.static(path.join(__dirname, '..', 'public')));

// // Routes
// app.use('/track', trackRoutes);
// app.use('/api', authRoutes);

// app.get('*', (req, res) => {
//     res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
//   });

// module.exports = app;


const express = require('express');
const corsMiddleware = require('./middleware/corsMiddleware');
const trackRoutes = require('./routes/track'); // For /track routes
const trackDataRoutes = require('./routes/trackdata'); // For /trackdata routes
const authRoutes = require('./routes/auth');
const app = express();
const path = require('path');
const bodyParser = require('body-parser');

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(corsMiddleware);

app.use(express.static(path.join(__dirname, '..', 'public')));

// Routes
app.use('/track', trackRoutes); 
app.use('/trackdata', trackDataRoutes); 
app.use('/api', authRoutes);

app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

module.exports = app;
