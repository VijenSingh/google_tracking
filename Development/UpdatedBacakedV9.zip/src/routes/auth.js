const express = require('express');
const router = express.Router();
const { loginUser,registerUser,getTrackedAllData } = require('../controllers/trackController');

router.post('/login', loginUser);
router.post('/register', registerUser);
router.get('/alltrackdata', getTrackedAllData);

module.exports = router;
