
// src/controllers/trackController.js
require('dotenv').config();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { ScanCommand, PutCommand, QueryCommand,GetCommand } = require('@aws-sdk/lib-dynamodb');
const dynamoDb = require('../config/db');

// Register User
exports.registerUser = async (req, res) => {
  const { username, password } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const params = {
      TableName: 'Users',
      Item: {
        username,
        password: hashedPassword
      }
    };
    await dynamoDb.send(new PutCommand(params));
    res.status(201).json({ message: 'User registered successfully' });
  } catch (err) {
    console.error('Error registering user:', err);
    res.status(500).json({ error: 'Failed to register user' });
  }
};


exports.loginUser = async (req, res) => {
  const { username, password } = req.body;
  try {
    const params = {
      TableName: 'Users',
      Key: { username }
    };
    const result = await dynamoDb.send(new GetCommand(params));
    const user = result.Item;
    if (user) {
      const isMatch = await bcrypt.compare(password, user.password);
      if (isMatch) {
        const token = jwt.sign({ userId: user.username }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.json({ token });
      } else {
        res.status(401).json({ error: 'Invalid credentials' });
      }
    } else {
      res.status(401).json({ error: 'Invalid credentials' });
    }
  } catch (err) {
    console.error('Error logging in user:', err);
    res.status(500).json({ error: 'Failed to log in user' });
  }
};


// Track Data
exports.trackData = async (req, res) => {

  const trackingData = {
    TableName: 'Tracking',
    Item: req.body
  };
  try {
    await dynamoDb.send(new PutCommand(trackingData));
    res.json({ message: 'Tracking data saved successfully' });
  } catch (err) {
    console.error('Error saving tracking data:', err);
    res.status(500).json({ error: 'Failed to save tracking data' });
  }
};

// Get Tracked Data
exports.getTrackedData = async (req, res) => {
  try {
    const params = {
      TableName: 'Tracking'
    };
    const result = await dynamoDb.send(new ScanCommand(params));
    res.json(result.Items);
  } catch (err) {
    console.error('Error retrieving tracking data:', err);
    res.status(500).json({ error: 'Error retrieving tracking data' });
  }
};
